package com.example.myrecycler;

public class Data {
    String name;

    double rating;

    Integer imageId;

    public Data(String name, double rating, Integer imageId) {
        this.name = name;
        this.rating = rating;
        this.imageId = imageId;
    }
}
