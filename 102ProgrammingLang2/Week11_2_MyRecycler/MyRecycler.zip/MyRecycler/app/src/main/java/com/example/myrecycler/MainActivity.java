package com.example.myrecycler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //1. 데이터 생성
        String[] titles = {
                "명지분식",
                "진짜루",
                "황소식당",
                "미스터피자",
                "수인김치찜",
                "명지곱창",
                "스시하나에"
        };

        Integer[] images = {
                R.drawable.movie1,
                R.drawable.movie2,
                R.drawable.movie3,
                R.drawable.movie4,
                R.drawable.movie5,
                R.drawable.movie6,
                R.drawable.movie7
        };

        ArrayList<Data> restaurants = new ArrayList<>();
        for (int i=0; i < 7; i++) {
            restaurants.add(new Data(titles[i], 4.5, images[i]));
        }

        //adapter
        MyAdapter adapter = new MyAdapter(restaurants);

        //리사이클러뷰 세팅
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.listView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);
    }
}